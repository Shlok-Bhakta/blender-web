#define main prior_worker_stress_main
#include "bridge.cc"
struct Pair{double number;int count;};
#undef main
#include <cstdarg>

static int sentinel=123;
static int64_t compiled_variadic(int marker,...) {
 va_list args;va_start(args,marker);
 int first=va_arg(args,int);double fraction=va_arg(args,double);int64_t wide=va_arg(args,int64_t);int*pointer=va_arg(args,int*);Pair aggregate=va_arg(args,Pair);long double extended=va_arg(args,long double);int last=va_arg(args,int);va_end(args);
 assert(marker==8&&first==-7&&fraction==1.5&&wide==((1LL<<54)+13)&&pointer==&sentinel&&aggregate.number==1.25&&aggregate.count==9&&extended==1.5L&&last==8);
 return ((1LL<<54)+29);
}
static void mixed_callback(ffi_cif*,void* result,void** arguments,void*) {
 assert(*static_cast<int*>(arguments[0])==8);
 assert(*static_cast<int*>(arguments[1])==-7);
 assert(*static_cast<double*>(arguments[2])==1.5);
 assert(*static_cast<int64_t*>(arguments[3])==((1LL<<54)+13));
 assert(*static_cast<int**>(arguments[4])==&sentinel);
 auto aggregate=*static_cast<Pair*>(arguments[5]);assert(aggregate.number==1.25&&aggregate.count==9);
 assert(*static_cast<long double*>(arguments[6])==1.5L);
 fprintf(stderr,"Mixed final=%d longdouble=%g type-size=%zu align=%u\n",*static_cast<int*>(arguments[7]),double(*static_cast<long double*>(arguments[6])),ffi_type_longdouble.size,ffi_type_longdouble.alignment);
 assert(*static_cast<int*>(arguments[7])==8);
 *static_cast<int64_t*>(result)=((1LL<<54)+29);
}
static void long_double_callback(ffi_cif*,void* result,void** arguments,void*) {
 *static_cast<long double*>(result)=*static_cast<long double*>(arguments[0])+*static_cast<long double*>(arguments[1]);
}
struct Single { double value; };
static void single_callback(ffi_cif*,void* result,void** arguments,void*) {
 assert(*static_cast<int*>(arguments[0])==2);
 auto aggregate=*static_cast<Single*>(arguments[1]);assert(aggregate.value==1.25);
 assert(*static_cast<double*>(arguments[2])==2.5);*static_cast<double*>(result)=aggregate.value+2.5;
}
static void zero_fixed_callback(ffi_cif*,void* result,void** arguments,void*) {
 *static_cast<int*>(result)=*static_cast<int*>(arguments[0])+int(*static_cast<double*>(arguments[1]));
}
static int extended_main() {
 queue=em_proxying_queue_create();assert(queue);register_worker();
 ffi_type*fields[]={&ffi_type_double,&ffi_type_sint32,nullptr};ffi_type pair{};pair.type=FFI_TYPE_STRUCT;pair.elements=fields;
 ffi_type*single_fields[]={&ffi_type_double,nullptr};ffi_type single{};single.type=FFI_TYPE_STRUCT;single.elements=single_fields;
 for(int kind=0;kind<4;kind++) {
  ffi_cif cif;Callback fn=nullptr;
  ffi_type*mixed[]={&ffi_type_sint32,&ffi_type_sint32,&ffi_type_double,&ffi_type_sint64,&ffi_type_pointer,&pair,&ffi_type_longdouble,&ffi_type_sint32};
  ffi_type*extended[]={&ffi_type_longdouble,&ffi_type_longdouble};
  ffi_type*small[]={&ffi_type_sint32,&single,&ffi_type_double};
  ffi_type*zero[]={&ffi_type_sint32,&ffi_type_double};
  if(kind==0){assert(ffi_prep_cif_var(&cif,FFI_DEFAULT_ABI,1,8,&ffi_type_sint64,mixed)==FFI_OK);fn=mixed_callback;}
  if(kind==1){assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,2,&ffi_type_longdouble,extended)==FFI_OK);fn=long_double_callback;}
  if(kind==2){assert(ffi_prep_cif_var(&cif,FFI_DEFAULT_ABI,1,3,&ffi_type_double,small)==FFI_OK);fn=single_callback;}
  if(kind==3){assert(ffi_prep_cif_var(&cif,FFI_DEFAULT_ABI,0,2,&ffi_type_sint32,zero)==FFI_OK);fn=zero_fixed_callback;}
  void*code=nullptr;auto*memory=static_cast<ffi_closure*>(ffi_closure_alloc(sizeof(ffi_closure),&code));assert(memory);
  assert(ffi_prep_closure_loc(memory,&cif,fn,nullptr,code)==FFI_OK);
  auto invoke=[&]{
   if(kind==0)assert(reinterpret_cast<int64_t(*)(int,...)>(code)(8,-7,1.5,(1LL<<54)+13,&sentinel,Pair{1.25,9},1.5L,8)==((1LL<<54)+29));
   if(kind==1)assert(reinterpret_cast<long double(*)(long double,long double)>(code)(1.25L,2.5L)==3.75L);
   if(kind==2)assert(reinterpret_cast<double(*)(int,...)>(code)(2,Single{1.25},2.5)==3.75);
   if(kind==3)assert(reinterpret_cast<int(*)(...)>(code)(7,2.5)==9);
  };
  auto both=[&]{
   invoke();
   if(kind==0){
    int marker=8,first=-7,last=8;double fraction=1.5;int64_t wide=(1LL<<54)+13;int*pointer=&sentinel;Pair aggregate{1.25,9};long double extended=1.5L;
    void*values[]={&marker,&first,&fraction,&wide,&pointer,&aggregate,&extended,&last};int64_t result=0;
    ffi_call(&cif,FFI_FN(code),&result,values);assert(result==((1LL<<54)+29));
    result=0;ffi_call(&cif,FFI_FN(compiled_variadic),&result,values);assert(result==((1LL<<54)+29));
   }
   if(kind==1){long double a=1.25L,b=2.5L,result=0;void*values[]={&a,&b};ffi_call(&cif,FFI_FN(code),&result,values);assert(result==3.75L);}
   if(kind==2){int marker=2;Single aggregate{1.25};double b=2.5,result=0;void*values[]={&marker,&aggregate,&b};ffi_call(&cif,FFI_FN(code),&result,values);assert(result==3.75);}
   if(kind==3){int a=7;double b=2.5;ffi_arg result=0;void*values[]={&a,&b};ffi_call(&cif,FFI_FN(code),&result,values);assert(int(result)==9);}
  };
  both();for(int i=0;i<8;i++){std::thread t(both);t.join();}
  ffi_closure_free(memory);fprintf(stderr,"Extended ABI category %d passed\n",kind);
 }
 assert(calls.load()==72);assert(closures.empty()&&workers.size()==1);
 printf("{\"originalLibffi\":\"%s\",\"extendedSignatureKinds\":4,\"calls\":%u,\"longDoubleExact\":true,\"mixedVarargsExact\":true,\"singleFieldAggregateVarargsExact\":true,\"zeroFixedVarargsExact\":true}\n",ffi_get_version(),calls.load());
 unregister_worker(nullptr);em_proxying_queue_destroy(queue);return 0;
}
int main(){return extended_main();}
