#include <emscripten.h>
#include <emscripten/threading.h>
#include <emscripten/proxying.h>
#include <ffi.h>
#include <algorithm>
#include <atomic>
#include <cassert>
#include <cmath>
#include <cerrno>
#include <climits>
#include <condition_variable>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <mutex>
#include <thread>
#include <vector>
using Callback=void(*)(ffi_cif*,void*,void**,void*);
struct Closure{ffi_closure*memory;void*code;ffi_cif*cif;Callback function;void*user;std::atomic<unsigned>active{0};};
struct Worker{pthread_t id;unsigned epoch=0;std::atomic<unsigned>waits{0};bool sleeping=false,alive=true,notice=false;};
static em_proxying_queue*queue=nullptr;
static bool negative_control=false,skip_wake_reconcile=false,force_polling=false;
static std::atomic<bool>free_wait_observed{false};
static std::atomic<unsigned>calls{0},registrations{0},progress{0},queued_notices{0};
static std::mutex registry_mutex;
static unsigned epoch=0;
static std::vector<pthread_t>workers;
static std::vector<std::shared_ptr<Worker>>states;
static std::vector<Closure*>closures;
static thread_local std::shared_ptr<Worker>self;
static thread_local std::vector<uintptr_t>installed;
static thread_local unsigned local_epoch=UINT_MAX,guard=0,queue_depth=0;
static thread_local Closure*invoking=nullptr;
extern "C" void*__real_ffi_closure_alloc(size_t,void**);
extern "C" void __real_ffi_closure_free(void*);
extern "C" ffi_status __real_ffi_prep_closure_loc(ffi_closure*,ffi_cif*,Callback,void*,void*);
extern "C" ffi_status ffi_web_install_closure(ffi_closure*,ffi_cif*,void*,void*,void*);
extern "C" int __real_emscripten_futex_wait(volatile void*,uint32_t,double);
extern "C" int __real_pthread_create(pthread_t*,const pthread_attr_t*,void*(*)(void*),void*);
EM_JS_DEPS(ffi_events,"$setWasmTableEntry");
EM_JS(void,ensure_table,(uintptr_t index),{if(wasmTable.length<=index)wasmTable.grow(index+1-wasmTable.length);});
EM_JS(void,clear_table,(uintptr_t index),{setWasmTableEntry(index,null);});
EM_JS(int,table_size,(),{return wasmTable.length;});
static void changed(){progress.fetch_add(1);emscripten_futex_wake(&progress,INT_MAX);}
static void dispatch(ffi_cif*cif,void*result,void**arguments,void*data){
 auto*c=static_cast<Closure*>(data);c->active.fetch_add(1);auto*previous=invoking;invoking=c;
 c->function(cif,result,arguments,c->user);invoking=previous;c->active.fetch_sub(1);calls.fetch_add(1);changed();
}
// The registry mutex protects closure descriptors while compiling local wrappers.
static void apply_locked(){
 if(local_epoch==epoch)return;
 for(auto index:installed)clear_table(index);installed.clear();
 for(auto*c:closures){ensure_table(reinterpret_cast<uintptr_t>(c->code));assert(ffi_web_install_closure(c->memory,c->cif,reinterpret_cast<void*>(dispatch),c,c->code)==FFI_OK);installed.push_back(reinterpret_cast<uintptr_t>(c->code));}
 local_epoch=epoch;if(self)self->epoch=epoch;changed();
}
static void reconcile(void*){guard++;{std::lock_guard<std::mutex>lock(registry_mutex);apply_locked();}guard--;}
static void notice(void*){guard++;{std::lock_guard<std::mutex>lock(registry_mutex);if(self)self->notice=false;apply_locked();}guard--;}
static void drain(){if(guard||queue_depth||!queue)return;queue_depth++;emscripten_proxy_execute_queue(queue);queue_depth--;}
extern "C" int __wrap_emscripten_futex_wait(volatile void*address,uint32_t value,double timeout){
 if(!self||guard||queue_depth)return __real_emscripten_futex_wait(address,value,timeout);
 const double deadline=(timeout<0||!std::isfinite(timeout))?INFINITY:emscripten_get_now()+timeout;
 drain();guard++;{std::lock_guard<std::mutex>lock(registry_mutex);apply_locked();self->sleeping=true;changed();}guard--;
 double remaining=std::isfinite(deadline)?std::max(0.,deadline-emscripten_get_now()):INFINITY;
 auto wait_once=[&](double duration){self->waits.fetch_add(1);return __real_emscripten_futex_wait(address,value,duration);};
 int result;
 if(force_polling){
  for(;;){double left=std::isfinite(deadline)?std::max(0.,deadline-emscripten_get_now()):INFINITY;result=wait_once(std::min(2.,left));if(result!=-ETIMEDOUT||(std::isfinite(deadline)&&emscripten_get_now()>=deadline))break;}
 }else result=wait_once(remaining);
 guard++;{std::lock_guard<std::mutex>lock(registry_mutex);if(!skip_wake_reconcile)apply_locked();self->sleeping=false;changed();}guard--;drain();return result;
}
static void sync(pthread_t thread,void(*function)(void*),void*data){
 if(pthread_equal(thread,pthread_self()))function(data);
 else{queue_depth++;bool ok=emscripten_proxy_sync(queue,thread,function,data);queue_depth--;assert(ok);drain();}
}
static void register_worker(){
 guard++;{std::lock_guard<std::mutex>lock(registry_mutex);self=std::make_shared<Worker>();self->id=pthread_self();states.push_back(self);workers.push_back(self->id);apply_locked();registrations.fetch_add(1);}guard--;
}
static void unregister_worker(void*){
 guard++;{std::lock_guard<std::mutex>lock(registry_mutex);
 for(auto index:installed)clear_table(index);installed.clear();local_epoch=UINT_MAX;
 auto id=pthread_self();workers.erase(std::find(workers.begin(),workers.end(),id));
 self->alive=false;states.erase(std::find(states.begin(),states.end(),self));self.reset();changed();}guard--;
}
struct Start{void*(*function)(void*);void*data;};
static void*start_worker(void*argument){auto start=*static_cast<Start*>(argument);delete static_cast<Start*>(argument);register_worker();void*result;pthread_cleanup_push(unregister_worker,nullptr);result=start.function(start.data);pthread_cleanup_pop(1);return result;}
extern "C" int __wrap_pthread_create(pthread_t*t,const pthread_attr_t*a,void*(*f)(void*),void*d){if(!queue)return __real_pthread_create(t,a,f,d);auto*s=new Start{f,d};int result=__real_pthread_create(t,a,start_worker,s);if(result)delete s;return result;}
struct Allocation{size_t size;void**code;void*memory;};
static void allocate(void*data){auto*a=static_cast<Allocation*>(data);a->memory=__real_ffi_closure_alloc(a->size,a->code);}
extern "C" void*__wrap_ffi_closure_alloc(size_t size,void**code){Allocation a{size,code,nullptr};sync(emscripten_main_runtime_thread_id(),allocate,&a);return a.memory;}
static void publish(unsigned requested,std::vector<std::shared_ptr<Worker>>targets){
 reconcile(nullptr);sync(emscripten_main_runtime_thread_id(),reconcile,nullptr);
 for(auto&s:targets){
  if(pthread_equal(s->id,pthread_self()))continue;
  guard++;bool send=false;{std::lock_guard<std::mutex>lock(registry_mutex);if(s->alive&&!s->sleeping&&s->epoch<requested&&!s->notice){s->notice=true;send=true;}}guard--;
  if(send){queue_depth++;int queued=emscripten_proxy_async(queue,s->id,notice,nullptr);queue_depth--;if(queued)queued_notices.fetch_add(1);else{guard++;{std::lock_guard<std::mutex>lock(registry_mutex);assert(!s->alive);}guard--;}}
 }
 for(;;){
  guard++;bool done=true;unsigned observed;
  {std::lock_guard<std::mutex>lock(registry_mutex);for(auto&s:targets)if(s->alive&&!s->sleeping&&s->epoch<requested)done=false;observed=progress.load();}guard--;
  if(done)break;__wrap_emscripten_futex_wait(&progress,observed,INFINITY);
 }
}
extern "C" ffi_status __wrap_ffi_prep_closure_loc(ffi_closure*memory,ffi_cif*cif,Callback fn,void*user,void*code){
 if(negative_control){ensure_table(reinterpret_cast<uintptr_t>(code));return __real_ffi_prep_closure_loc(memory,cif,fn,user,code);}
 auto*c=new Closure{memory,code,cif,fn,user};unsigned requested;std::vector<std::shared_ptr<Worker>>targets;ffi_status status;
 guard++;{std::lock_guard<std::mutex>lock(registry_mutex);assert(std::none_of(closures.begin(),closures.end(),[&](auto*p){return p->memory==memory;}));ensure_table(reinterpret_cast<uintptr_t>(code));status=__real_ffi_prep_closure_loc(memory,cif,dispatch,c,code);if(status==FFI_OK){closures.push_back(c);requested=++epoch;targets=states;}}guard--;
 if(status!=FFI_OK){delete c;return status;}publish(requested,targets);return status;
}
static void release(void*data){__real_ffi_closure_free(data);}
extern "C" void __wrap_ffi_closure_free(void*memory){
 Closure*c=nullptr;unsigned requested=0;std::vector<std::shared_ptr<Worker>>targets;
 guard++;{std::lock_guard<std::mutex>lock(registry_mutex);auto it=std::find_if(closures.begin(),closures.end(),[&](auto*p){return p->memory==memory;});if(it!=closures.end()){c=*it;assert(invoking!=c);closures.erase(it);requested=++epoch;targets=states;}}guard--;
 if(c){publish(requested,targets);while(c->active.load()){free_wait_observed.store(true);unsigned observed=progress.load();if(c->active.load())__wrap_emscripten_futex_wait(&progress,observed,INFINITY);}delete c;}
 sync(emscripten_main_runtime_thread_id(),release,memory);
}
