# Callback publication without bridge polling

Extract this evidence archive to `build/native/parity-probes/ffi-events`. Use Emscripten 4.0.23 and the pinned original libffi 3.5.2 fixture from the earlier worker evidence's REPRODUCE.md. The Wasm backend includes the same checked marshalling fixes.

```sh
bash build/native/parity-probes/ffi-events/build.sh
node build/native/parity-probes/ffi-events/check.js 1000
node build/native/parity-probes/ffi-events/check.js 8 polling-control
node build/native/parity-probes/ffi-events/check.js 8 skip-wake
```

The last two commands must fail. The polling control repeats physical waits every two milliseconds and fails the idle-count assertion. The wake control skips installing deferred callback changes and traps when a sleeping worker calls the newly published callback.

The regular test holds eight workers in raw indefinite futex waits. It requires no repeated physical waits over 100 ms and no extra waits or queued notices during 200 closure publication/retirement pairs. A final live callback must be installed before each of those workers resumes user code. Existing condition-variable workers also run; the pinned SDK itself uses 100 ms condition-wait slices, which this bridge does not remove.

```sh
bash build/native/parity-probes/ffi-events/build-browser.sh
bash build/native/parity-probes/ffi-events/build-browser-abi.sh
python3 web/tools/serve.py --directory build/native/parity-probes/ffi-events --port 8099
# In another shell, from the repository root:
PLAYWRIGHT_BROWSERS_PATH=/tmp/blender-web-browsers node build/native/parity-probes/ffi-events/browser.cjs
WEB_FFI_ABI=1 PLAYWRIGHT_BROWSERS_PATH=/tmp/blender-web-browsers node build/native/parity-probes/ffi-events/browser.cjs
```

The browser harness uses the repository's Playwright installation and isolation headers. It requires exit 0, exact call values and no browser errors. build-abi.sh also builds the extended ABI suite for Node. The included native comparison uses the same argument values and normal C ABI through original libffi embedded in pinned native Blender.

The prototype marks managed workers as sleeping around their original futex wait. Publications can defer local table changes for those workers. Before returning to user code, a waking worker installs the latest registry state under the same mutex used by publishers. Active workers acknowledge changes. Notices are coalesced, and sleeping workers need none. Retirement waits on a signalled progress word for active callbacks.

The C++ drivers are GPL-2.0-or-later. ffi.c retains libffi's upstream license notice. The prototype does not modify the production SDK or application. Full application worker coverage, additional callback termination cases and performance measurements remain necessary.
