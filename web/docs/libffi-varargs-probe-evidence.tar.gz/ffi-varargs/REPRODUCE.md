# Extended libffi ABI check

Extract this archive under `build/native/parity-probes`, preserving the `ffi-varargs` and `ffi-reentrant` directories. Use Emscripten 4.0.23 and the original libffi 3.5.2 fixture prepared using REPRODUCE.md in the earlier libffi worker evidence archive. The shared source archive hash is recorded in acceptance.json.

From the repository root:

```sh
bash build/native/parity-probes/ffi-varargs/build.sh
node build/native/parity-probes/ffi-varargs/check.js
bash build/native/parity-probes/ffi-varargs/build-stress.sh
node build/native/parity-probes/ffi-varargs/stress.js 1000
```

The archived failing binary can be checked immediately with `node build/native/parity-probes/ffi-varargs/before/check.js`. It must fail the final integer assertion, observing 29 where 8 was passed. Its matching sources are in before; copy them to the ffi-varargs root and run build.sh to recompile that historical case.

The forward marshaller now computes ascending argument offsets, reserves one aligned stack buffer, then copies each value to its ABI position. The previous descending per-argument allocation placed some padding after an argument instead of before the next. Tests call both the original libffi closure and an independently compiler-generated va_arg function.

The native driver resolves libffi symbols from pinned native Blender's original _ctypes extension. Its original 72 callback and nine compiled-varargs calls also pass. Rebuild the shared driver with the native libffi headers configured as described by the earlier evidence; the C++ test source is included. native-verify.py reruns the comparison from the pinned native Blender with the evidence directory after --.

The C++ drivers are GPL-2.0-or-later. ffi.c retains the original libffi license notice. These changes do not modify the production application or SDK.
