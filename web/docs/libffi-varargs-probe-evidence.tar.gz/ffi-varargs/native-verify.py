import bpy,ctypes,_ctypes,hashlib,json,sys
from pathlib import Path
p=Path(sys.argv[sys.argv.index('--')+1]).resolve()
original=ctypes.CDLL(_ctypes.__file__,mode=ctypes.RTLD_GLOBAL)
original.ffi_get_version.restype=ctypes.c_char_p
assert original.ffi_get_version()==b'3.5.2'
probe=ctypes.CDLL(str(p/'native-check.so'))
probe.run_extended_ffi_check.argtypes=[];probe.run_extended_ffi_check.restype=ctypes.c_int
assert probe.run_extended_ffi_check()==0
report=dict(blenderVersion=bpy.app.version_string,blenderRevision=bpy.app.build_hash.decode(),originalBlenderLibffi='3.5.2',callbackCalls=72,compiledVariadicCalls=9,extendedSignatureKinds=4,exactValues=True,nativeModuleSha256=hashlib.sha256(Path(_ctypes.__file__).read_bytes()).hexdigest(),driverSha256=hashlib.sha256((p/'native-check.cc').read_bytes()).hexdigest(),librarySha256=hashlib.sha256((p/'native-check.so').read_bytes()).hexdigest())
(p/'native-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
