# Generic libffi worker prototype

Isolated Node pthread Wasm test, not linked into Blender.

The source and artifacts in acceptance.json passed 1,000 signature reuses and 9,332 exact calls. A callback can create, invoke and free another callback while another worker waits to free the first. The same binary with `8 locked-free` retains the old registry lock across retirement and times out after 15 seconds. `1000` passes in 30.803 seconds with a 90-second test deadline. The earlier 30-second deadline was too short for that workload.

Run from the repository root with the pinned SDK and existing isolated libffi fixture:

```sh
bash build/native/parity-probes/ffi-reentrant/build.sh
node build/native/parity-probes/ffi-reentrant/check.js 1000
```

The build uses libffi 3.5.2 from the prior cpython prototype, replaces its Wasm backend object with the checked patch, then links the pthread driver. Source archive SHA-256, original native Blender readback, source/binary/log hashes and limitations are in acceptance.json. native-check.cc uses the same four signature categories with native Blender's original embedded libffi.

Two-millisecond polling, forced termination, cancellation, self-free, stale callback calls, untracked workers, further ABI layouts and memory lifetime remain unresolved. This is not production ctypes support.
