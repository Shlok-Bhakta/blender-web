import bpy,ctypes,_ctypes,hashlib,json,sys
from pathlib import Path
base=Path(sys.argv[sys.argv.index('--')+1]).resolve()
native=ctypes.CDLL(_ctypes.__file__,mode=ctypes.RTLD_GLOBAL)
native.ffi_get_version.restype=ctypes.c_char_p
assert native.ffi_get_version()==b'3.5.2'
probe=ctypes.CDLL(str(base/'native-check.so'))
probe.run_ffi_native_check.argtypes=[ctypes.c_char_p]
probe.run_ffi_native_check.restype=ctypes.c_int
assert probe.run_ffi_native_check(str(base/'native-result.json').encode())==0
result=json.loads((base/'native-result.json').read_text())
result.update(blenderVersion=bpy.app.version_string,blenderRevision=bpy.app.build_hash.decode(),
 originalBlenderFFI=True,nativeModuleSha256=hashlib.sha256(Path(_ctypes.__file__).read_bytes()).hexdigest(),
 driverSha256=hashlib.sha256((base/'native-check.cc').read_bytes()).hexdigest(),
 librarySha256=hashlib.sha256((base/'native-check.so').read_bytes()).hexdigest())
(base/'native-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
