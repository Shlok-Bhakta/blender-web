# Reproduce from the pinned source

The executable uses Node 22.22.2 and Emscripten 4.0.23. Run from the repository root. Extract this evidence archive to `build/native/parity-probes/ffi-reentrant`. Obtain the pinned original `libffi-3.5.2.tar.gz` using Blender's `FFI_URI` in `blender/build_files/build_environment/cmake/versions.cmake`. Its SHA-256 must match acceptance.json.

```sh
source /tmp/blender-web-emsdk/emsdk_env.sh
mkdir -p build/native/parity-probes/cpython/ffi/source build/native/parity-probes/cpython/ffi/build
tar -xf build/native/deps/downloads/libffi-3.5.2.tar.gz --strip-components=1 -C build/native/parity-probes/cpython/ffi/source
REPOSITORY_ROOT="$PWD"
cd build/native/parity-probes/cpython/ffi/build
CC=emcc CXX=em++ AR=emar RANLIB=emranlib NM=emnm CFLAGS='-O3 -pthread -msimd128 -fwasm-exceptions' CXXFLAGS='-O3 -pthread -msimd128 -fwasm-exceptions' emconfigure ../source/configure --host=wasm32-unknown-emscripten --prefix="$REPOSITORY_ROOT/build/native/parity-probes/cpython/prefix" --disable-shared --enable-static --disable-dependency-tracking --disable-builddir --disable-multi-os-directory --disable-raw-api --disable-docs
emmake make -j2
emmake make install
cd "$REPOSITORY_ROOT"
bash build/native/parity-probes/ffi-reentrant/build.sh
node build/native/parity-probes/ffi-reentrant/check.js 1000
```

`timeout 15s node build/native/parity-probes/ffi-reentrant/check.js 8 locked-free` must time out during callback retirement with the old lock behavior. `node build/native/parity-probes/ffi-reentrant/check.js negative` reproduces the missing-table-entry failure when worker propagation is disabled. These negative controls are expected to fail. The passing 1,000-cycle run needs more than the original 30-second deadline; the recorded run used 90 seconds.

The original native driver binary is included and hashed. Run the pinned native Blender with `--background --factory-startup --python-exit-code 1 --python build/native/parity-probes/ffi-reentrant/native-verify.py -- build/native/parity-probes/ffi-reentrant` to rerun its independent comparison. The driver resolves ffi symbols from Blender's own `_ctypes` extension. It does not contain a replacement libffi.

The C++ test drivers are GPL-2.0-or-later. The original ffi.c retains libffi's upstream license notice. This experiment does not modify the production SDK or application.
