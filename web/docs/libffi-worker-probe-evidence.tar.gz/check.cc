#include <emscripten.h>
#include <emscripten/threading.h>
#include <emscripten/proxying.h>
#include <ffi.h>
#include <algorithm>
#include <atomic>
#include <cassert>
#include <cmath>
#include <cerrno>
#include <condition_variable>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <thread>
#include <vector>

using Callback=void(*)(ffi_cif*,void*,void**,void*);
struct Closure {
 ffi_closure* memory;void* code;ffi_cif* cif;Callback function;void* user;
 std::atomic<unsigned> active{0};
};
static em_proxying_queue* queue=nullptr;
static bool negative_control=false;
static bool lock_during_retirement=false;
static std::atomic<bool> free_wait_observed{false};
static std::mutex registry_mutex;
static std::vector<pthread_t> workers;
static std::vector<Closure*> closures;
static thread_local bool tracked=false;
static thread_local unsigned queue_depth=0;
static thread_local Closure* invoking=nullptr;
static std::atomic<unsigned> calls{0},registrations{0};
extern "C" void* __real_ffi_closure_alloc(size_t,void**);
extern "C" void __real_ffi_closure_free(void*);
extern "C" ffi_status __real_ffi_prep_closure_loc(ffi_closure*,ffi_cif*,Callback,void*,void*);
extern "C" ffi_status ffi_web_install_closure(ffi_closure*,ffi_cif*,void*,void*,void*);
extern "C" int __real_emscripten_futex_wait(volatile void*,uint32_t,double);
extern "C" int __real_pthread_create(pthread_t*,const pthread_attr_t*,void*(*)(void*),void*);

EM_JS_DEPS(ffi_threads,"$setWasmTableEntry");
EM_JS(void,ensure_table,(uintptr_t index),{
 if(wasmTable.length<=index)wasmTable.grow(index+1-wasmTable.length);
});
EM_JS(void,clear_table,(uintptr_t index),{setWasmTableEntry(index,null);});
EM_JS(int,table_size,(),{return wasmTable.length;});

static void drain(){
 if(queue_depth||!queue)return;
 queue_depth++;emscripten_proxy_execute_queue(queue);queue_depth--;
}
// Prototype polling is intentional. Production needs a wakeup protocol that
// does not add this timeout to every managed worker's futex waits.
extern "C" int __wrap_emscripten_futex_wait(volatile void*address,uint32_t value,double timeout){
 if(!tracked||!queue)return __real_emscripten_futex_wait(address,value,timeout);
 const double deadline=(timeout<0||!std::isfinite(timeout))?INFINITY:emscripten_get_now()+timeout;
 for(;;){
  drain();
  double remaining=std::isfinite(deadline)?std::max(0.,deadline-emscripten_get_now()):2.;
  int result=__real_emscripten_futex_wait(address,value,std::min(remaining,2.));
  drain();
  if(result!=-ETIMEDOUT)return result;
  if(std::isfinite(deadline)&&emscripten_get_now()>=deadline)return result;
 }

}
static void sync(pthread_t thread,void(*function)(void*),void* data){
 if(pthread_equal(thread,pthread_self()))function(data);
 else {
  // Queue insertion itself can acquire malloc and futex locks. Do not re-enter
  // this queue until the synchronous queue operation has released those locks.
  queue_depth++;bool completed=emscripten_proxy_sync(queue,thread,function,data);queue_depth--;
  assert(completed);drain();
 }
}
static void dispatch(ffi_cif*cif,void* result,void** arguments,void*data){
 auto*closure=static_cast<Closure*>(data);
 closure->active.fetch_add(1);
 auto* previous=invoking;invoking=closure;
 closure->function(cif,result,arguments,closure->user);
 invoking=previous;
 closure->active.fetch_sub(1);calls.fetch_add(1);
}
static void install(void*data){
 auto*c=static_cast<Closure*>(data);ensure_table(reinterpret_cast<uintptr_t>(c->code));
 assert(ffi_web_install_closure(c->memory,c->cif,reinterpret_cast<void*>(dispatch),c,c->code)==FFI_OK);
}
static void clear(void*data){clear_table(reinterpret_cast<uintptr_t>(static_cast<Closure*>(data)->code));}
static void broadcast(void(*function)(void*),Closure*c){
 sync(emscripten_main_runtime_thread_id(),function,c);
 for(auto id:workers)if(!pthread_equal(id,emscripten_main_runtime_thread_id()))sync(id,function,c);
}
static void register_worker(){
 std::lock_guard<std::mutex> lock(registry_mutex);
 tracked=true;
 for(auto*c:closures)install(c);
 workers.push_back(pthread_self());registrations.fetch_add(1);
}
static void unregister_worker(void*){
 std::lock_guard<std::mutex> lock(registry_mutex);
 auto self=pthread_self();auto it=std::find(workers.begin(),workers.end(),self);assert(it!=workers.end());workers.erase(it);tracked=false;
}
struct Start{void*(*function)(void*);void*data;};
static void*start_worker(void*argument){
 auto start=*static_cast<Start*>(argument);delete static_cast<Start*>(argument);
 register_worker();void* result;
 pthread_cleanup_push(unregister_worker,nullptr);
 result=start.function(start.data);
 pthread_cleanup_pop(1);
 return result;
}
extern "C" int __wrap_pthread_create(pthread_t*thread,const pthread_attr_t*attributes,void*(*function)(void*),void*data){
 if(!queue)return __real_pthread_create(thread,attributes,function,data);
 auto*start=new Start{function,data};int result=__real_pthread_create(thread,attributes,start_worker,start);if(result)delete start;return result;
}
struct Allocation{size_t size;void**code;void* memory;};
static void allocate(void*data){auto*a=static_cast<Allocation*>(data);a->memory=__real_ffi_closure_alloc(a->size,a->code);}
extern "C" void* __wrap_ffi_closure_alloc(size_t size,void**code){
 Allocation a{size,code,nullptr};sync(emscripten_main_runtime_thread_id(),allocate,&a);return a.memory;
}
extern "C" ffi_status __wrap_ffi_prep_closure_loc(ffi_closure*memory,ffi_cif*cif,Callback function,void*user,void*code){
 std::lock_guard<std::mutex> lock(registry_mutex);
 assert(std::none_of(closures.begin(),closures.end(),[&](auto*c){return c->memory==memory;}));
 if(negative_control){ensure_table(reinterpret_cast<uintptr_t>(code));return __real_ffi_prep_closure_loc(memory,cif,function,user,code);}
 auto*c=new Closure{memory,code,cif,function,user};ensure_table(reinterpret_cast<uintptr_t>(code));
 auto status=__real_ffi_prep_closure_loc(memory,cif,dispatch,c,code);
 if(status!=FFI_OK){delete c;return status;}
 closures.push_back(c);broadcast(install,c);return status;
}
static void release(void*data){__real_ffi_closure_free(data);}
extern "C" void __wrap_ffi_closure_free(void*memory){
 std::unique_lock<std::mutex> lock(registry_mutex);
 auto it=std::find_if(closures.begin(),closures.end(),[&](auto*c){return c->memory==memory;});
 if(it!=closures.end()){
  auto*c=*it;assert(invoking!=c);closures.erase(it);
  // A running callback can use libffi itself. Do not hold its registry lock
  // while waiting for the callback to finish creating or freeing closures.
  if(!lock_during_retirement)lock.unlock();
  while(c->active.load()){free_wait_observed.store(true);__wrap_emscripten_futex_wait(&c->active,c->active.load(),2);}
  if(!lock_during_retirement)lock.lock();
  broadcast(clear,c);
  lock.unlock();
  while(c->active.load()){free_wait_observed.store(true);__wrap_emscripten_futex_wait(&c->active,c->active.load(),2);}
  lock.lock();
  delete c;
 }
 sync(emscripten_main_runtime_thread_id(),release,memory);
}

struct Pair{double number;int count;};
static void scalar(ffi_cif*,void*result,void**args,void*data){*static_cast<int*>(result)=*static_cast<int*>(args[0])*3+*static_cast<int*>(args[1])+*static_cast<int*>(data);}
static void wide(ffi_cif*,void*result,void**args,void*){*static_cast<int64_t*>(result)=*static_cast<int64_t*>(args[0])+static_cast<int64_t>(*static_cast<double*>(args[1]))+*static_cast<int*>(args[2]);}
static void pair_callback(ffi_cif*,void*result,void**args,void*){auto value=*static_cast<Pair*>(args[0]);*static_cast<Pair*>(result)={value.number+.5,value.count+int(*static_cast<int64_t*>(args[1]))};}
static void varargs(ffi_cif*,void*result,void**args,void*){assert(*static_cast<int*>(args[0])==2);*static_cast<double*>(result)=*static_cast<double*>(args[1])+*static_cast<double*>(args[2]);}
static void check(void*code,int kind){
 if(kind==0)assert(reinterpret_cast<int(*)(int,int)>(code)(7,9)==35);
 if(kind==1)assert(reinterpret_cast<int64_t(*)(int64_t,double,int)>(code)((1LL<<54)+13,4.,-2)==((1LL<<54)+15));
 if(kind==2){auto result=reinterpret_cast<Pair(*)(Pair,int64_t)>(code)({1.25,9},7);assert(result.number==1.75&&result.count==16);}
 if(kind==3)assert(reinterpret_cast<double(*)(int,...)>(code)(2,1.5,4.5)==6.);
}
struct Blocking {std::atomic<unsigned> entered{0},release{0};};
static void blocking(ffi_cif*,void*result,void**arguments,void*data){
 auto*b=static_cast<Blocking*>(data);b->entered.store(1);
 while(!b->release.load())emscripten_futex_wait(&b->release,0,2);
 ffi_cif nested_cif;ffi_type* nested_args[]={&ffi_type_sint32,&ffi_type_sint32};
 assert(ffi_prep_cif(&nested_cif,FFI_DEFAULT_ABI,2,&ffi_type_sint32,nested_args)==FFI_OK);
 void* nested_code=nullptr;auto* nested_memory=static_cast<ffi_closure*>(ffi_closure_alloc(sizeof(ffi_closure),&nested_code));assert(nested_memory);
 int bias=5;assert(ffi_prep_closure_loc(nested_memory,&nested_cif,scalar,&bias,nested_code)==FFI_OK);
 check(nested_code,0);ffi_closure_free(nested_memory);
 fprintf(stderr,"Nested callback creation and retirement passed\n");
 *static_cast<int*>(result)=*static_cast<int*>(arguments[0])+1;
}
static int run(int argc,char**argv){
 negative_control=argc>1&&std::strcmp(argv[1],"negative")==0;
 lock_during_retirement=argc>2&&std::strcmp(argv[2],"locked-free")==0;
 unsigned iterations=argc>1&&!negative_control?std::strtoul(argv[1],nullptr,10):80;
 assert(iterations>=4&&iterations<=4000);
 queue=em_proxying_queue_create();assert(queue);register_worker();
 std::mutex mutex;std::condition_variable condition;bool stop=false;unsigned generation=0,complete=0,ready=0;void* code=nullptr;int kind=0;
 std::vector<std::thread> old;
 for(int i=0;i<8;i++)old.emplace_back([&]{
  std::unique_lock<std::mutex> lock(mutex);ready++;condition.notify_all();unsigned seen=0;
  for(;;){condition.wait(lock,[&]{return stop||generation>seen;});if(stop)break;seen=generation;void* target=code;int signature=kind;lock.unlock();check(target,signature);lock.lock();complete++;condition.notify_all();}
 });
 {std::unique_lock<std::mutex> lock(mutex);condition.wait(lock,[&]{return ready==8;});}
 int maximum=0,bounded=0;int bias=5;
 for(unsigned iteration=0;iteration<iterations;iteration++){
  ffi_cif cif;ffi_type* fields[]={&ffi_type_double,&ffi_type_sint32,nullptr};ffi_type pair{};pair.type=FFI_TYPE_STRUCT;pair.elements=fields;
  ffi_type* scalar_args[]={&ffi_type_sint32,&ffi_type_sint32};
  ffi_type* wide_args[]={&ffi_type_sint64,&ffi_type_double,&ffi_type_sint32};
  ffi_type* pair_args[]={&pair,&ffi_type_sint64};
  ffi_type* variable_args[]={&ffi_type_sint32,&ffi_type_double,&ffi_type_double};
  kind=iteration%4;Callback callback=nullptr;
  if(kind==0){assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,2,&ffi_type_sint32,scalar_args)==FFI_OK);callback=scalar;}
  if(kind==1){assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,3,&ffi_type_sint64,wide_args)==FFI_OK);callback=wide;}
  if(kind==2){assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,2,&pair,pair_args)==FFI_OK);callback=pair_callback;}
  if(kind==3){assert(ffi_prep_cif_var(&cif,FFI_DEFAULT_ABI,1,3,&ffi_type_double,variable_args)==FFI_OK);callback=varargs;}
  auto*memory=static_cast<ffi_closure*>(ffi_closure_alloc(sizeof(ffi_closure),&code));assert(memory&&code);
  assert(ffi_prep_closure_loc(memory,&cif,callback,&bias,code)==FFI_OK);check(code,kind);
  {std::unique_lock<std::mutex> lock(mutex);complete=0;generation++;condition.notify_all();condition.wait(lock,[&]{return complete==8;});}
  if(iteration%4==0){std::thread fresh([&]{check(code,kind);});fresh.join();}
  maximum=std::max(maximum,table_size());if(iteration==0)bounded=maximum;assert(maximum==bounded);
  ffi_closure_free(memory);
  if(iteration%20==0)fprintf(stderr,"Generic closure reuse %u\n",iteration);
 }

 std::vector<std::thread> publishers;
 for(int i=0;i<4;i++)publishers.emplace_back([&]{
  for(int j=0;j<20;j++){
   ffi_cif cif;ffi_type*args[]={&ffi_type_sint32,&ffi_type_sint32};
   assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,2,&ffi_type_sint32,args)==FFI_OK);
   void*target=nullptr;auto*memory=static_cast<ffi_closure*>(ffi_closure_alloc(sizeof(ffi_closure),&target));assert(memory&&target);
   assert(ffi_prep_closure_loc(memory,&cif,scalar,&bias,target)==FFI_OK);check(target,0);ffi_closure_free(memory);
  }
 });
 for(auto&thread:publishers)thread.join();
 assert(table_size()<=bounded+4);
 fprintf(stderr,"Concurrent publishers passed\n");
 {std::lock_guard<std::mutex> lock(mutex);stop=true;}condition.notify_all();for(auto&thread:old)thread.join();

 ffi_cif blocking_cif;ffi_type*blocking_args[]={&ffi_type_sint32};
 assert(ffi_prep_cif(&blocking_cif,FFI_DEFAULT_ABI,1,&ffi_type_sint32,blocking_args)==FFI_OK);
 void*target=nullptr;auto*memory=static_cast<ffi_closure*>(ffi_closure_alloc(sizeof(ffi_closure),&target));assert(memory&&target);
 Blocking state;assert(ffi_prep_closure_loc(memory,&blocking_cif,blocking,&state,target)==FFI_OK);
 free_wait_observed.store(false);std::atomic<bool> freed{false};
 std::thread reader([&]{assert(reinterpret_cast<int(*)(int)>(target)(41)==42);});
 while(!state.entered.load())emscripten_futex_wait(&state.entered,0,2);
 std::thread freer([&]{ffi_closure_free(memory);freed.store(true);});
 while(!free_wait_observed.load())emscripten_futex_wait(&state.entered,1,2);
 assert(!freed.load());state.release.store(1);emscripten_futex_wake(&state.release,1);
 reader.join();freer.join();assert(freed.load());
 fprintf(stderr,"In-flight free waited for callback completion\n");
 pthread_t exiting;assert(pthread_create(&exiting,nullptr,[](void*)->void*{pthread_exit(nullptr);return nullptr;},nullptr)==0);
 assert(pthread_join(exiting,nullptr)==0);
 fprintf(stderr,"Explicit pthread_exit cleanup passed\n");
 maximum=table_size();
 assert(closures.empty()&&workers.size()==1);
 printf("{\"originalLibffi\":\"%s\",\"existingWorkers\":8,\"newWorkers\":%u,\"signatureReuseIterations\":%u,\"signatureKinds\":4,\"calls\":%u,\"tableSize\":%d,\"serialTableSize\":%d,\"registeredThreads\":%u,\"concurrentPublishers\":4,\"concurrentClosures\":80,\"inFlightFree\":true,\"nestedCreationDuringRetirement\":true,\"pthreadExitCleanup\":true,\"pollingMilliseconds\":2,\"genericCIF\":true,\"libffiIntegrated\":false}\n",ffi_get_version(),(iterations+3)/4,iterations,calls.load(),maximum,bounded,registrations.load());
 unregister_worker(nullptr);em_proxying_queue_destroy(queue);return 0;
}

int main(int argc,char**argv){try{return run(argc,argv);}catch(const std::exception&error){fprintf(stderr,"C++ failure: %s\n",error.what());return 1;}}
