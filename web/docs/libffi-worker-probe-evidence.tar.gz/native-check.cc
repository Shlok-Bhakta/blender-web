#include <ffi.h>
#include <pthread.h>
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <cstring>
using Callback=void(*)(ffi_cif*,void*,void**,void*);
struct Pair{double number;int count;};
static void scalar(ffi_cif*,void*result,void**args,void*data){*static_cast<int*>(result)=*static_cast<int*>(args[0])*3+*static_cast<int*>(args[1])+*static_cast<int*>(data);}
static void wide(ffi_cif*,void*result,void**args,void*){*static_cast<int64_t*>(result)=*static_cast<int64_t*>(args[0])+static_cast<int64_t>(*static_cast<double*>(args[1]))+*static_cast<int*>(args[2]);}
static void pair_callback(ffi_cif*,void*result,void**args,void*){auto value=*static_cast<Pair*>(args[0]);*static_cast<Pair*>(result)={value.number+.5,value.count+int(*static_cast<int64_t*>(args[1]))};}
static void varargs(ffi_cif*,void*result,void**args,void*){assert(*static_cast<int*>(args[0])==2);*static_cast<double*>(result)=*static_cast<double*>(args[1])+*static_cast<double*>(args[2]);}
static void check(void*code,int kind){
 if(kind==0)assert(reinterpret_cast<int(*)(int,int)>(code)(7,9)==35);
 if(kind==1)assert(reinterpret_cast<int64_t(*)(int64_t,double,int)>(code)((1LL<<54)+13,4.,-2)==((1LL<<54)+15));
 if(kind==2){auto result=reinterpret_cast<Pair(*)(Pair,int64_t)>(code)({1.25,9},7);assert(result.number==1.75&&result.count==16);}
 if(kind==3)assert(reinterpret_cast<double(*)(int,...)>(code)(2,1.5,4.5)==6.);
}

struct Invocation {void*code;int kind;};
static void* invoke(void*argument){auto*a=static_cast<Invocation*>(argument);check(a->code,a->kind);return nullptr;}
extern "C" int run_ffi_native_check(const char*output){
 assert(std::strcmp(ffi_get_version(),"3.5.2")==0);
 int bias=5,kind=0;
 for(unsigned iteration=0;iteration<80;iteration++){
  ffi_cif cif;ffi_type* fields[]={&ffi_type_double,&ffi_type_sint32,nullptr};ffi_type pair{};pair.type=FFI_TYPE_STRUCT;pair.elements=fields;
  ffi_type* scalar_args[]={&ffi_type_sint32,&ffi_type_sint32};
  ffi_type* wide_args[]={&ffi_type_sint64,&ffi_type_double,&ffi_type_sint32};
  ffi_type* pair_args[]={&pair,&ffi_type_sint64};
  ffi_type* variable_args[]={&ffi_type_sint32,&ffi_type_double,&ffi_type_double};
  kind=iteration%4;Callback callback=nullptr;
  if(kind==0){assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,2,&ffi_type_sint32,scalar_args)==FFI_OK);callback=scalar;}
  if(kind==1){assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,3,&ffi_type_sint64,wide_args)==FFI_OK);callback=wide;}
  if(kind==2){assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,2,&pair,pair_args)==FFI_OK);callback=pair_callback;}
  if(kind==3){assert(ffi_prep_cif_var(&cif,FFI_DEFAULT_ABI,1,3,&ffi_type_double,variable_args)==FFI_OK);callback=varargs;}

  void*code=nullptr;auto*memory=static_cast<ffi_closure*>(ffi_closure_alloc(sizeof(ffi_closure),&code));assert(memory&&code);
  assert(ffi_prep_closure_loc(memory,&cif,callback,&bias,code)==FFI_OK);check(code,kind);
  pthread_t workers[8];Invocation argument{code,kind};
  for(auto&worker:workers)assert(pthread_create(&worker,nullptr,invoke,&argument)==0);
  for(auto worker:workers)assert(pthread_join(worker,nullptr)==0);
  ffi_closure_free(memory);
 }
 FILE*file=std::fopen(output,"w");assert(file);
 std::fprintf(file,"{\"originalLibffi\":\"%s\",\"calls\":720,\"signatureKinds\":4,\"workerCalls\":640,\"exactValues\":true}\n",ffi_get_version());
 assert(std::fclose(file)==0);return 0;
}
