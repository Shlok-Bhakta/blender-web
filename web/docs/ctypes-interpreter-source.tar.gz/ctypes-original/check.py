import ctypes as c, gc, json, sys, threading

def run(addresses):
    unraisable=[]
    old_hook=sys.unraisablehook
    sys.unraisablehook=lambda value:unraisable.append(str(value.exc_value))
    class Pair(c.Structure):
        _fields_=[('number',c.c_double),('count',c.c_int)]
    def function(name,result,*args,**flags):
        return c.CFUNCTYPE(result,*args,**flags)(addresses[name])
    scalar=function('fixture_int',c.c_int,c.c_int,c.c_int)
    wide=function('fixture_wide',c.c_int64,c.c_int64,c.c_double,c.c_int)
    aggregate=function('fixture_pair',Pair,Pair,c.c_int64)
    extended=function('fixture_long_double',c.c_longdouble,c.c_longdouble,c.c_longdouble)
    assert scalar(7,9)==35
    assert wide((1<<54)+13,4.,-2)==(1<<54)+15
    result=aggregate(Pair(1.25,9),7)
    assert (result.number,result.count)==(1.75,16)
    assert extended(1.25,2.5)==3.75
    variable=function('fixture_mixed',c.c_int64,c.c_int)
    sentinel=c.c_int(123)
    assert variable(8,c.c_int(-7),c.c_double(1.5),c.c_int64((1<<54)+13),c.byref(sentinel),Pair(1.25,9),c.c_longdouble(1.5),c.c_int(8))==(1<<54)+29
    data=(c.c_int64*4)(1,(1<<54)+13,-7,42)
    assert list(data)==[1,(1<<54)+13,-7,42]
    copied=c.create_string_buffer(c.sizeof(data))
    c.memmove(copied,data,c.sizeof(data))
    assert c.string_at(copied,c.sizeof(data))==bytes(data)
    c.memset(copied,0,c.sizeof(copied));assert not any(copied.raw)
    import numpy as np
    assert np.__version__=='2.3.4'
    assert np.ctypeslib.as_array(data).tolist()==list(data)
    numeric=np.array(list(data),dtype=np.int64)
    view=np.ctypeslib.as_ctypes(numeric)
    assert list(view)==list(data)
    assert numeric.ctypes.data_as(c.POINTER(c.c_int64))[1]==(1<<54)+13
    sum_array=function('fixture_sum',c.c_int64,np.ctypeslib.ndpointer(dtype=np.int64,ndim=1,flags='C_CONTIGUOUS'),c.c_size_t)
    assert sum_array(numeric,4)==(1<<54)+49
    try:sum_array(numeric[::2],2)
    except c.ArgumentError:pass
    else:raise AssertionError('Non-contiguous array accepted')
    assert sum_array(numeric,4)==(1<<54)+49
    c.pythonapi.Py_GetVersion.restype=c.c_char_p
    assert c.pythonapi.Py_GetVersion().decode().startswith(sys.version.split()[0])
    c.pythonapi.PyErr_SetString.argtypes=[c.py_object,c.c_char_p]
    c.pythonapi.PyErr_SetString.restype=None
    try:c.pythonapi.PyErr_SetString(ValueError,b'ctypes Python API proof')
    except ValueError as error:assert str(error)=='ctypes Python API proof'
    else:raise AssertionError('Python API exception was lost')
    c.pythonapi.Py_IncRef.argtypes=[c.py_object];c.pythonapi.Py_IncRef.restype=None
    c.pythonapi.Py_DecRef.argtypes=[c.py_object];c.pythonapi.Py_DecRef.restype=None
    object_value=[];references=sys.getrefcount(object_value)
    c.pythonapi.Py_IncRef(object_value);assert sys.getrefcount(object_value)==references+1
    c.pythonapi.Py_DecRef(object_value);assert sys.getrefcount(object_value)==references
    assert scalar(7,9)==35
    process=c.CDLL(None);process.strlen.argtypes=[c.c_char_p];process.strlen.restype=c.c_size_t
    assert process.strlen(b'Blender ctypes')==14
    try:process.this_symbol_does_not_exist_in_blender_web
    except AttributeError:pass
    else:raise AssertionError('Missing static symbol accepted')
    c.set_errno(0);error=function('fixture_errno',c.c_int,c.c_int,use_errno=True)
    assert error(33)==-1 and c.get_errno()==33
    start=function('fixture_pool_start',c.c_int)
    invoke=function('fixture_pool_run',c.c_int64,c.c_void_p,c.c_int)
    stop=function('fixture_pool_stop',c.c_int)
    assert start()==0
    callbacks=0
    try:
        for cycle in range(60):
            mode=cycle%3
            if mode==0:
                callback=c.CFUNCTYPE(c.c_int,c.c_int,c.c_int)(lambda a,b:a*3+b+5);expected=35*4
            elif mode==1:
                callback=c.CFUNCTYPE(c.c_int64,c.c_int64,c.c_double,c.c_int)(lambda a,b,d:a+int(b)+d);expected=((1<<54)+15)*4
            else:
                callback=c.CFUNCTYPE(c.c_int,Pair)(lambda value:int(value.number*4)+value.count);expected=14*4
            assert invoke(c.cast(callback,c.c_void_p).value,mode)==expected
            callbacks+=4
            del callback;gc.collect()
    finally:assert stop()==0
    thread_results=[]
    callback=c.CFUNCTYPE(c.c_int,c.c_int,c.c_int)(lambda a,b:a*3+b+5)
    threads=[threading.Thread(target=lambda:thread_results.append(callback(7,9))) for _ in range(8)]
    for thread in threads:thread.start()
    for thread in threads:thread.join()
    assert thread_results==[35]*8
    del callback;gc.collect()
    assert not unraisable,unraisable
    sys.unraisablehook=old_hook
    return dict(originalCtypes=True,numpyCtypesInterop=True,numpyVersion=np.__version__,noncontiguousArrayRejected=True,pythonVersion=sys.version.split()[0],pointerBytes=c.sizeof(c.c_void_p),longBytes=c.sizeof(c.c_long),wideIntegersExact=True,aggregateArgumentsAndReturn=True,longDouble=True,mixedVarargs=True,memoryOperations=True,pythonAPI=True,pythonAPIErrorRecovery=True,pythonReferenceCounts=True,processNamespace=True,missingSymbolRejected=True,errno=True,existingForeignWorkers=4,foreignWorkerCallbacks=callbacks,pythonThreadCallbacks=8,signatureReuseIterations=60,unraisableErrors=unraisable)

if __name__=='__main__':
    from _ffi_fixture import addresses
    print(json.dumps(run(addresses)))
