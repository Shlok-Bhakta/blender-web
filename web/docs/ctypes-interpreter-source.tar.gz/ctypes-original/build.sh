set -e
source /tmp/blender-web-emsdk/emsdk_env.sh >/dev/null 2>&1
export BINARYEN_CORES=1
ctypes_probe=build/native/parity-probes/ctypes-original
ctypes_source=build/native/deps/python-extensions/python
ctypes_prefix=build/native/deps/prefix
for ctypes_unit in _ctypes callbacks callproc cfield stgdict; do
 emcc -O2 -g1 -pthread -msimd128 -fwasm-exceptions -DPy_BUILD_CORE_BUILTIN=1 -DPY_CALL_TRAMPOLINE -DHAVE_FFI_CLOSURE_ALLOC=1 -DHAVE_FFI_PREP_CIF_VAR=1 -DHAVE_FFI_PREP_CLOSURE_LOC=1 -I"$ctypes_prefix/include/python3.13" -I"$ctypes_source/Include/internal" -I"$ctypes_source/Modules/_ctypes" -Ibuild/native/parity-probes/cpython/prefix/include -c "$ctypes_source/Modules/_ctypes/$ctypes_unit.c" -o "$ctypes_probe/$ctypes_unit.o"
done
emar rcs "$ctypes_probe/ctypes.a" "$ctypes_probe"/*.o
em++ "$ctypes_probe/driver.cc" "$ctypes_probe/loader.cc" "$ctypes_probe/fixture.cc" -I"$ctypes_prefix/include/python3.13" -I"$ctypes_prefix/include" -Ibuild/native/parity-probes/cpython/prefix/include -O2 -g1 -pthread -msimd128 -fwasm-exceptions -Wl,--start-group "$ctypes_prefix"/lib/blender-web-numpy/*.a "$ctypes_probe/ctypes.a" build/native/parity-probes/ffi-events-exit/libffi.a "$ctypes_prefix/lib/libpython3.13.a" "$ctypes_prefix/lib/libz.a" -Wl,--end-group -sUSE_BZIP2=1 -sALLOW_TABLE_GROWTH=1 -sPROXY_TO_PTHREAD=1 -sPTHREAD_POOL_SIZE=20 -sPTHREAD_POOL_SIZE_STRICT=0 -sEXIT_RUNTIME=1 -sALLOW_MEMORY_GROWTH=1 -sINITIAL_MEMORY=134217728 -sSTACK_SIZE=8388608 -sDEFAULT_PTHREAD_STACK_SIZE=8388608 -sWASMFS=1 -sFORCE_FILESYSTEM=1 -sENVIRONMENT=node,worker '-sEXPORTED_FUNCTIONS=["_main","_malloc","_free"]' -Wl,--wrap=ffi_closure_alloc -Wl,--wrap=ffi_prep_closure_loc -Wl,--wrap=ffi_closure_free -Wl,--wrap=pthread_create -Wl,--wrap=emscripten_futex_wait -Wl,--wrap=dlopen -Wl,--wrap=dlsym -Wl,--wrap=dlclose -Wl,--wrap=dlerror --preload-file build/native/assets/python3.13@/python/lib/python3.13 --preload-file "$ctypes_probe/check.py"@/check.py -o "$ctypes_probe/check.js"
