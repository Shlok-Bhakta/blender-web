#ifndef FFI_NO_PYTHON
#include <Python.h>
#endif
#include <atomic>
#include <cassert>
#include <cerrno>
#include <condition_variable>
#include <cstdarg>
#include <cstdint>
#include <mutex>
#include <thread>
#include <vector>
struct Pair{double number;int count;};
extern "C" int fixture_int(int a,int b){return a*3+b+5;}
extern "C" int64_t fixture_wide(int64_t a,double b,int c){return a+int64_t(b)+c;}
extern "C" Pair fixture_pair(Pair a,int64_t b){return {a.number+.5,a.count+int(b)};}
extern "C" long double fixture_long_double(long double a,long double b){return a+b;}
extern "C" int64_t fixture_sum(const int64_t*values,std::size_t count){int64_t result=0;for(std::size_t i=0;i<count;i++)result+=values[i];return result;}
extern "C" int fixture_errno(int error){errno=error;return -1;}
extern "C" int64_t fixture_mixed(int marker,...){
 va_list args;va_start(args,marker);int first=va_arg(args,int);double fraction=va_arg(args,double);int64_t wide=va_arg(args,int64_t);int*pointer=va_arg(args,int*);Pair aggregate=va_arg(args,Pair);long double extended=va_arg(args,long double);int last=va_arg(args,int);va_end(args);
 assert(marker==8&&first==-7&&fraction==1.5&&wide==((1LL<<54)+13)&&*pointer==123&&aggregate.number==1.25&&aggregate.count==9&&extended==1.5L&&last==8);return (1LL<<54)+29;
}
static std::mutex pool_mutex;static std::condition_variable pool_condition;
static std::vector<std::thread>pool;static bool pool_stop=false;static unsigned pool_ready=0,pool_generation=0,pool_completed=0;
static void*pool_code=nullptr;static int pool_mode=0;static int64_t pool_sum=0;
extern "C" int fixture_pool_start(){
 assert(pool.empty());pool_stop=false;pool_ready=pool_completed=pool_generation=0;
 for(int i=0;i<4;i++)pool.emplace_back([]{
  std::unique_lock<std::mutex>lock(pool_mutex);pool_ready++;pool_condition.notify_all();unsigned seen=0;
  for(;;){pool_condition.wait(lock,[&]{return pool_stop||pool_generation>seen;});if(pool_stop)break;seen=pool_generation;void*code=pool_code;int mode=pool_mode;lock.unlock();
   int64_t value=0;if(mode==0)value=reinterpret_cast<int(*)(int,int)>(code)(7,9);
   if(mode==1)value=reinterpret_cast<int64_t(*)(int64_t,double,int)>(code)((1LL<<54)+13,4.,-2);
   if(mode==2)value=reinterpret_cast<int(*)(Pair)>(code)({1.25,9});
   lock.lock();pool_sum+=value;pool_completed++;pool_condition.notify_all();
  }
 });
 std::unique_lock<std::mutex>lock(pool_mutex);pool_condition.wait(lock,[]{return pool_ready==4;});return 0;
}
extern "C" int64_t fixture_pool_run(void*code,int mode){
 std::unique_lock<std::mutex>lock(pool_mutex);assert(pool.size()==4);pool_code=code;pool_mode=mode;pool_sum=0;pool_completed=0;pool_generation++;pool_condition.notify_all();pool_condition.wait(lock,[]{return pool_completed==4;});return pool_sum;
}
extern "C" int fixture_pool_stop(){
 {std::lock_guard<std::mutex>lock(pool_mutex);pool_stop=true;}pool_condition.notify_all();for(auto&t:pool)t.join();pool.clear();return 0;
}
#ifndef FFI_NO_PYTHON
extern "C" PyObject*PyInit__ffi_fixture(){
 static PyModuleDef definition={PyModuleDef_HEAD_INIT,"_ffi_fixture",nullptr,-1,nullptr};PyObject*module=PyModule_Create(&definition);if(!module)return nullptr;
 PyObject*addresses=PyDict_New();if(!addresses){Py_DECREF(module);return nullptr;}
 #define ADDRESS(n) {PyObject*value=PyLong_FromVoidPtr(reinterpret_cast<void*>(&n));if(!value||PyDict_SetItemString(addresses,#n,value)<0){Py_XDECREF(value);Py_DECREF(addresses);Py_DECREF(module);return nullptr;}Py_DECREF(value);}
 ADDRESS(fixture_int);ADDRESS(fixture_wide);ADDRESS(fixture_pair);ADDRESS(fixture_long_double);ADDRESS(fixture_errno);ADDRESS(fixture_sum);ADDRESS(fixture_mixed);ADDRESS(fixture_pool_start);ADDRESS(fixture_pool_run);ADDRESS(fixture_pool_stop);
 #undef ADDRESS
 if(PyModule_AddObject(module,"addresses",addresses)<0){Py_DECREF(addresses);Py_DECREF(module);return nullptr;}return module;
}
#endif
