#include <Python.h>
#include <cstring>
#include <cstdlib>
#include <dlfcn.h>
static thread_local const char*last_error=nullptr;
static void*handle=reinterpret_cast<void*>(uintptr_t(0x1000));
extern "C" void*__wrap_dlopen(const char*name,int){if(!name){last_error=nullptr;return handle;}last_error="Only the static process namespace is available in this isolated probe";return nullptr;}
extern "C" void*__wrap_dlsym(void*h,const char*name){
 last_error=nullptr;if(h!=handle){last_error="Unknown static namespace";return nullptr;}
 #define SYMBOL(n) if(std::strcmp(name,#n)==0)return reinterpret_cast<void*>(&n)
 SYMBOL(Py_GetVersion);SYMBOL(PyErr_Occurred);SYMBOL(Py_IncRef);SYMBOL(Py_DecRef);SYMBOL(PyErr_SetString);SYMBOL(strlen);SYMBOL(memmove);SYMBOL(memset);SYMBOL(malloc);SYMBOL(free);
 #undef SYMBOL
 last_error="Symbol is not registered in this isolated static namespace";return nullptr;
}
extern "C" int __wrap_dlclose(void*h){if(h==handle)return 0;last_error="Unknown static namespace";return -1;}
extern "C" char*__wrap_dlerror(){auto*error=last_error;last_error=nullptr;return const_cast<char*>(error);}
