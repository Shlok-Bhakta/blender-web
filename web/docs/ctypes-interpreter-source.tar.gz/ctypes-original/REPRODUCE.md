# Original CPython ctypes in Wasm

Extract the source archive under `build/native/parity-probes`, preserving the ctypes-original and ffi-events-exit directories. Build the repository's original Python/NumPy dependencies first. Prepare pinned libffi 3.5.2 using the earlier worker evidence instructions; no SDK files need modification. Build the bridge with `bash build/native/parity-probes/ffi-events-exit/build.sh`.

```sh
bash build/native/parity-probes/ctypes-original/build.sh
(cd build/native/parity-probes/ctypes-original && node check.js)
bash build/native/parity-probes/ctypes-original/build-browser.sh
python3 web/tools/serve.py --directory build/native/parity-probes/ctypes-original --port 8100
# In another shell, from the repository root:
PLAYWRIGHT_BROWSERS_PATH=/tmp/blender-web-browsers node build/native/parity-probes/ctypes-original/browser.cjs
```

The binary archive provides the already-built Node/browser Wasm, preload data and native fixture. The Node file packager reads data relative to the current directory, hence the subshell above.

Compile the native fixture with `c++ -shared -fPIC -O2 -fno-exceptions -fno-rtti -DFFI_NO_PYTHON build/native/parity-probes/ctypes-original/fixture.cc -o build/native/parity-probes/ctypes-original/native-fixture.so`, then run pinned native Blender with `--background --factory-startup --python-exit-code 1 --python build/native/parity-probes/ctypes-original/native-verify.py -- build/native/parity-probes/ctypes-original`. The same Python checks must match, excluding the explicitly recorded 32/64-bit pointer and long sizes.

The CPython _ctypes sources are original, unchanged files from the pinned 3.13.13 source. Build definitions enable the actual libffi closure and variadic APIs. loader.cc exposes a small real static process namespace, including Python API and libc functions, and rejects named dynamic libraries. It does not implement general shared-library loading.

The bridge also tests exit from inside a running callback while another worker waits to retire it. Cleanup releases the active-call counter. `node check.js 8 leak-exit-counter` in the ffi-events-exit directory disables that cleanup and must time out after the callback exits. Its matching positive and negative logs are in the source archive.

The authored C++ drivers and loader are GPL-2.0-or-later. CPython, NumPy and libffi retain their original licenses in the pinned dependency sources and existing repository notices. This is an isolated interpreter proof, not production Blender ctypes support.
