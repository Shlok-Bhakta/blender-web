#include <Python.h>
#include <blender-web-numpy.hh>
#include "../ffi-events-exit/bridge.cc"
extern "C" PyObject*PyInit__ctypes();
extern "C" PyObject*PyInit__ffi_fixture();
int main(){
 queue=em_proxying_queue_create();assert(queue);register_worker();
 GHOST_web_register_numpy();
 assert(PyImport_AppendInittab("_ctypes",PyInit__ctypes)==0);
 assert(PyImport_AppendInittab("_ffi_fixture",PyInit__ffi_fixture)==0);
 PyConfig config;PyConfig_InitIsolatedConfig(&config);PyConfig_SetBytesString(&config,&config.home,"/python");
 PyStatus status=Py_InitializeFromConfig(&config);PyConfig_Clear(&config);if(PyStatus_Exception(status))Py_ExitStatusException(status);
 int result=PyRun_SimpleString("import runpy\nrunpy.run_path('/check.py',run_name='__main__')\n");
 int final=Py_FinalizeEx();assert(closures.empty());unregister_worker(nullptr);em_proxying_queue_destroy(queue);return result||final;
}
