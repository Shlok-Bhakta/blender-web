import bpy,ctypes,_ctypes,hashlib,json,runpy,sys
from pathlib import Path
p=Path(sys.argv[sys.argv.index('--')+1]).resolve()
module=ctypes.CDLL(_ctypes.__file__,mode=ctypes.RTLD_GLOBAL);module.ffi_get_version.restype=ctypes.c_char_p
assert module.ffi_get_version()==b'3.5.2'
fixture=ctypes.CDLL(str(p/'native-fixture.so'))
names=['fixture_int','fixture_wide','fixture_pair','fixture_long_double','fixture_errno','fixture_sum','fixture_mixed','fixture_pool_start','fixture_pool_run','fixture_pool_stop']
addresses={name:ctypes.cast(getattr(fixture,name),ctypes.c_void_p).value for name in names}
result=runpy.run_path(str(p/'check.py'))['run'](addresses)
wasm=json.loads((p/'expanded.log').read_text().splitlines()[-1])
assert {k:v for k,v in result.items() if k not in ('pointerBytes','longBytes')}=={k:v for k,v in wasm.items() if k not in ('pointerBytes','longBytes')}
assert result['pointerBytes']==result['longBytes']==8
report=dict(blenderVersion=bpy.app.version_string,blenderRevision=bpy.app.build_hash.decode(),originalBlenderLibffi='3.5.2',samePythonChecks=True,exactValues=True,architectureDifferences=['pointerBytes','longBytes'],report=result,nativeModuleSha256=hashlib.sha256(Path(_ctypes.__file__).read_bytes()).hexdigest(),fixtureSourceSha256=hashlib.sha256((p/'fixture.cc').read_bytes()).hexdigest(),fixtureBinarySha256=hashlib.sha256((p/'native-fixture.so').read_bytes()).hexdigest(),pythonSourceSha256=hashlib.sha256((p/'check.py').read_bytes()).hexdigest())
(p/'native-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
