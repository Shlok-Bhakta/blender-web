const fs=require('node:fs');const path=require('node:path');const assert=require('node:assert/strict');
const {chromium}=require(require.resolve('playwright',{paths:[path.resolve('web/tests')]}));
const abi=process.env.WEB_FFI_ABI==='1';const suffix=abi?'-abi':'';
(async()=>{const browser=await chromium.launch({headless:true});const page=await browser.newPage();const errors=[];
page.on('pageerror',e=>errors.push(String(e)));page.on('console',m=>fs.appendFileSync('build/native/parity-probes/ffi-events-exit/browser.log',m.text()+'\n'));
try{await page.goto('http://127.0.0.1:8099/?iterations=1000'+(abi?'&abi=1':''));assert(await page.evaluate(()=>crossOriginIsolated));
 await page.waitForFunction(()=>window.probeExit===0||window.probeErrors.length||window.probeExit>0,null,{timeout:120000});
 const data=await page.evaluate(()=>({result:window.probeResult,exit:window.probeExit,output:window.probeOutput,errors:window.probeErrors,isolated:crossOriginIsolated}));
 fs.writeFileSync('build/native/parity-probes/ffi-events-exit/browser'+suffix+'-raw.json',JSON.stringify(data,null,2)+'\n');
 assert.equal(data.exit,0);assert.deepEqual(data.errors,[]);assert.deepEqual(errors,[]);assert.equal(data.result.calls,abi?72:9340);if(abi){assert(data.result.longDoubleExact&&data.result.mixedVarargsExact&&data.result.singleFieldAggregateVarargsExact&&data.result.zeroFixedVarargsExact);}else{assert.equal(data.result.threadExitDuringCallback,true);assert.equal(data.result.abandonedCallbacks,1);assert.equal(data.result.pollingMilliseconds,0);assert.equal(data.result.idleRepeatedWaits,0);assert.equal(data.result.sleepingWorkerQueuedNotices,0);}
 const report={...data.result,browserVersion:browser.version(),crossOriginIsolated:true,browserErrors:errors,exitCode:data.exit};
 fs.writeFileSync('build/native/parity-probes/ffi-events-exit/browser'+suffix+'-verification.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});