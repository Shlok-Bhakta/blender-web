struct Pair{double number;int count;};
static void scalar(ffi_cif*,void*result,void**args,void*data){*static_cast<int*>(result)=*static_cast<int*>(args[0])*3+*static_cast<int*>(args[1])+*static_cast<int*>(data);}
static void wide(ffi_cif*,void*result,void**args,void*){*static_cast<int64_t*>(result)=*static_cast<int64_t*>(args[0])+static_cast<int64_t>(*static_cast<double*>(args[1]))+*static_cast<int*>(args[2]);}
static void pair_callback(ffi_cif*,void*result,void**args,void*){auto value=*static_cast<Pair*>(args[0]);*static_cast<Pair*>(result)={value.number+.5,value.count+int(*static_cast<int64_t*>(args[1]))};}
static void varargs(ffi_cif*,void*result,void**args,void*){assert(*static_cast<int*>(args[0])==2);*static_cast<double*>(result)=*static_cast<double*>(args[1])+*static_cast<double*>(args[2]);}
static void check(void*code,int kind){
 if(kind==0)assert(reinterpret_cast<int(*)(int,int)>(code)(7,9)==35);
 if(kind==1)assert(reinterpret_cast<int64_t(*)(int64_t,double,int)>(code)((1LL<<54)+13,4.,-2)==((1LL<<54)+15));
 if(kind==2){auto result=reinterpret_cast<Pair(*)(Pair,int64_t)>(code)({1.25,9},7);assert(result.number==1.75&&result.count==16);}
 if(kind==3)assert(reinterpret_cast<double(*)(int,...)>(code)(2,1.5,4.5)==6.);
}
struct Blocking {std::atomic<unsigned> entered{0},release{0};};
static void blocking(ffi_cif*,void*result,void**arguments,void*data){
 auto*b=static_cast<Blocking*>(data);b->entered.store(1);
 while(!b->release.load())emscripten_futex_wait(&b->release,0,2);
 ffi_cif nested_cif;ffi_type* nested_args[]={&ffi_type_sint32,&ffi_type_sint32};
 assert(ffi_prep_cif(&nested_cif,FFI_DEFAULT_ABI,2,&ffi_type_sint32,nested_args)==FFI_OK);
 void* nested_code=nullptr;auto* nested_memory=static_cast<ffi_closure*>(ffi_closure_alloc(sizeof(ffi_closure),&nested_code));assert(nested_memory);
 int bias=5;assert(ffi_prep_closure_loc(nested_memory,&nested_cif,scalar,&bias,nested_code)==FFI_OK);
 check(nested_code,0);ffi_closure_free(nested_memory);
 fprintf(stderr,"Nested callback creation and retirement passed\n");
 *static_cast<int*>(result)=*static_cast<int*>(arguments[0])+1;
}
static void exiting_callback(ffi_cif*,void*,void**,void*data){
 auto*b=static_cast<Blocking*>(data);b->entered.store(1);
 while(!b->release.load())emscripten_futex_wait(&b->release,0,2);
 pthread_exit(reinterpret_cast<void*>(uintptr_t(0x55aa)));
}
static int run(int argc,char**argv){
 negative_control=argc>1&&std::strcmp(argv[1],"negative")==0;
 skip_wake_reconcile=argc>2&&std::strcmp(argv[2],"skip-wake")==0;
 force_polling=argc>2&&std::strcmp(argv[2],"polling-control")==0;
 skip_exit_cleanup=argc>2&&std::strcmp(argv[2],"leak-exit-counter")==0;
 unsigned iterations=argc>1&&!negative_control?std::strtoul(argv[1],nullptr,10):80;
 assert(iterations>=4&&iterations<=4000);
 queue=em_proxying_queue_create();assert(queue);register_worker();
 {
  std::atomic<unsigned>release_idle{0};void*final_code=nullptr;std::vector<std::thread>idle;
  for(int i=0;i<8;i++)idle.emplace_back([&]{emscripten_futex_wait(&release_idle,0,INFINITY);assert(release_idle.load()==1);check(final_code,0);});
  for(;;){guard++;unsigned count=0;{std::lock_guard<std::mutex>lock(registry_mutex);for(auto&s:states)if(s!=self&&s->sleeping)count++;}guard--;if(count==8)break;emscripten_thread_sleep(1);}
  emscripten_thread_sleep(20);
  auto idle_waits=[&]{guard++;unsigned count=0;{std::lock_guard<std::mutex>lock(registry_mutex);for(auto&s:states)if(s!=self)count+=s->waits.load();}guard--;return count;};
  unsigned before=idle_waits();emscripten_thread_sleep(100);unsigned after=idle_waits();fprintf(stderr,"Indefinitely sleeping workers: physical waits before=%u after=%u\n",before,after);assert(after==before);
  unsigned notices_before=queued_notices.load();int idle_bias=5;
  for(int i=0;i<200;i++){
   ffi_cif cif;ffi_type*args[]={&ffi_type_sint32,&ffi_type_sint32};assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,2,&ffi_type_sint32,args)==FFI_OK);
   void*target=nullptr;auto*memory=static_cast<ffi_closure*>(ffi_closure_alloc(sizeof(ffi_closure),&target));assert(memory);assert(ffi_prep_closure_loc(memory,&cif,scalar,&idle_bias,target)==FFI_OK);ffi_closure_free(memory);
  }
  assert(queued_notices.load()==notices_before);assert(idle_waits()==before);
  fprintf(stderr,"200 callback publications retired with no sleeping-worker notices or repeated waits\n");
  ffi_cif cif;ffi_type*args[]={&ffi_type_sint32,&ffi_type_sint32};assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,2,&ffi_type_sint32,args)==FFI_OK);
  auto*memory=static_cast<ffi_closure*>(ffi_closure_alloc(sizeof(ffi_closure),&final_code));assert(memory);assert(ffi_prep_closure_loc(memory,&cif,scalar,&idle_bias,final_code)==FFI_OK);
  release_idle.store(1);emscripten_futex_wake(&release_idle,INT_MAX);for(auto&thread:idle)thread.join();ffi_closure_free(memory);
  fprintf(stderr,"All eight workers installed the live callback before returning to user code\n");
 }
 std::mutex mutex;std::condition_variable condition;bool stop=false;unsigned generation=0,complete=0,ready=0;void* code=nullptr;int kind=0;
 std::vector<std::thread> old;
 for(int i=0;i<8;i++)old.emplace_back([&]{
  std::unique_lock<std::mutex> lock(mutex);ready++;condition.notify_all();unsigned seen=0;
  for(;;){condition.wait(lock,[&]{return stop||generation>seen;});if(stop)break;seen=generation;void* target=code;int signature=kind;lock.unlock();check(target,signature);lock.lock();complete++;condition.notify_all();}
 });
 {std::unique_lock<std::mutex> lock(mutex);condition.wait(lock,[&]{return ready==8;});}
 int maximum=0,bounded=0;int bias=5;
 for(unsigned iteration=0;iteration<iterations;iteration++){
  ffi_cif cif;ffi_type* fields[]={&ffi_type_double,&ffi_type_sint32,nullptr};ffi_type pair{};pair.type=FFI_TYPE_STRUCT;pair.elements=fields;
  ffi_type* scalar_args[]={&ffi_type_sint32,&ffi_type_sint32};
  ffi_type* wide_args[]={&ffi_type_sint64,&ffi_type_double,&ffi_type_sint32};
  ffi_type* pair_args[]={&pair,&ffi_type_sint64};
  ffi_type* variable_args[]={&ffi_type_sint32,&ffi_type_double,&ffi_type_double};
  kind=iteration%4;Callback callback=nullptr;
  if(kind==0){assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,2,&ffi_type_sint32,scalar_args)==FFI_OK);callback=scalar;}
  if(kind==1){assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,3,&ffi_type_sint64,wide_args)==FFI_OK);callback=wide;}
  if(kind==2){assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,2,&pair,pair_args)==FFI_OK);callback=pair_callback;}
  if(kind==3){assert(ffi_prep_cif_var(&cif,FFI_DEFAULT_ABI,1,3,&ffi_type_double,variable_args)==FFI_OK);callback=varargs;}
  auto*memory=static_cast<ffi_closure*>(ffi_closure_alloc(sizeof(ffi_closure),&code));assert(memory&&code);
  assert(ffi_prep_closure_loc(memory,&cif,callback,&bias,code)==FFI_OK);check(code,kind);
  {std::unique_lock<std::mutex> lock(mutex);complete=0;generation++;condition.notify_all();condition.wait(lock,[&]{return complete==8;});}
  if(iteration%4==0){std::thread fresh([&]{check(code,kind);});fresh.join();}
  maximum=std::max(maximum,table_size());if(iteration==0)bounded=maximum;assert(maximum==bounded);
  ffi_closure_free(memory);
  if(iteration%20==0)fprintf(stderr,"Generic closure reuse %u\n",iteration);
 }

 std::vector<std::thread> publishers;
 for(int i=0;i<4;i++)publishers.emplace_back([&]{
  for(int j=0;j<20;j++){
   ffi_cif cif;ffi_type*args[]={&ffi_type_sint32,&ffi_type_sint32};
   assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,2,&ffi_type_sint32,args)==FFI_OK);
   void*target=nullptr;auto*memory=static_cast<ffi_closure*>(ffi_closure_alloc(sizeof(ffi_closure),&target));assert(memory&&target);
   assert(ffi_prep_closure_loc(memory,&cif,scalar,&bias,target)==FFI_OK);check(target,0);ffi_closure_free(memory);
  }
 });
 for(auto&thread:publishers)thread.join();
 assert(table_size()<=bounded+4);
 fprintf(stderr,"Concurrent publishers passed\n");
 {std::lock_guard<std::mutex> lock(mutex);stop=true;}condition.notify_all();for(auto&thread:old)thread.join();

 ffi_cif blocking_cif;ffi_type*blocking_args[]={&ffi_type_sint32};
 assert(ffi_prep_cif(&blocking_cif,FFI_DEFAULT_ABI,1,&ffi_type_sint32,blocking_args)==FFI_OK);
 void*target=nullptr;auto*memory=static_cast<ffi_closure*>(ffi_closure_alloc(sizeof(ffi_closure),&target));assert(memory&&target);
 Blocking state;assert(ffi_prep_closure_loc(memory,&blocking_cif,blocking,&state,target)==FFI_OK);
 free_wait_observed.store(false);std::atomic<bool> freed{false};
 std::thread reader([&]{assert(reinterpret_cast<int(*)(int)>(target)(41)==42);});
 while(!state.entered.load())emscripten_futex_wait(&state.entered,0,2);
 std::thread freer([&]{ffi_closure_free(memory);freed.store(true);});
 while(!free_wait_observed.load())emscripten_futex_wait(&state.entered,1,2);
 assert(!freed.load());state.release.store(1);emscripten_futex_wake(&state.release,1);
 reader.join();freer.join();assert(freed.load());
 fprintf(stderr,"In-flight free waited for callback completion\n");
 pthread_t exiting;assert(pthread_create(&exiting,nullptr,[](void*)->void*{pthread_exit(nullptr);return nullptr;},nullptr)==0);
 assert(pthread_join(exiting,nullptr)==0);
 fprintf(stderr,"Explicit pthread_exit cleanup passed\n");
 {
  ffi_cif cif;ffi_type*args[]={&ffi_type_sint32};assert(ffi_prep_cif(&cif,FFI_DEFAULT_ABI,1,&ffi_type_sint32,args)==FFI_OK);
  void*target=nullptr;auto*memory=static_cast<ffi_closure*>(ffi_closure_alloc(sizeof(ffi_closure),&target));assert(memory);Blocking state;
  assert(ffi_prep_closure_loc(memory,&cif,exiting_callback,&state,target)==FFI_OK);
  pthread_t caller;assert(pthread_create(&caller,nullptr,[](void*code)->void*{reinterpret_cast<int(*)(int)>(code)(41);assert(false);return nullptr;},target)==0);
  while(!state.entered.load())emscripten_futex_wait(&state.entered,0,2);
  free_wait_observed.store(false);std::atomic<bool>finished{false};std::thread retiring([&]{ffi_closure_free(memory);finished.store(true);});
  while(!free_wait_observed.load())emscripten_futex_wait(&state.entered,1,2);
  state.release.store(1);emscripten_futex_wake(&state.release,1);void*result=nullptr;assert(pthread_join(caller,&result)==0);assert(result==reinterpret_cast<void*>(uintptr_t(0x55aa)));
  fprintf(stderr,"Callback exited its worker with the expected result; waiting for retirement\n");
  retiring.join();assert(finished.load()&&abandoned_callbacks.load()==1);
  fprintf(stderr,"Thread exit inside a running callback released its active-call counter\n");
 }
 maximum=table_size();
 assert(closures.empty()&&workers.size()==1);
 printf("{\"originalLibffi\":\"%s\",\"existingWorkers\":8,\"newWorkers\":%u,\"signatureReuseIterations\":%u,\"signatureKinds\":4,\"calls\":%u,\"tableSize\":%d,\"serialTableSize\":%d,\"registeredThreads\":%u,\"concurrentPublishers\":4,\"concurrentClosures\":80,\"inFlightFree\":true,\"nestedCreationDuringRetirement\":true,\"pthreadExitCleanup\":true,\"threadExitDuringCallback\":true,\"abandonedCallbacks\":1,\"pollingMilliseconds\":0,\"indefinitelySleepingWorkers\":8,\"idleRepeatedWaits\":0,\"sleepingWorkerPublications\":200,\"sleepingWorkerQueuedNotices\":0,\"genericCIF\":true,\"libffiIntegrated\":false}\n",ffi_get_version(),(iterations+3)/4,iterations,calls.load(),maximum,bounded,registrations.load());
 unregister_worker(nullptr);em_proxying_queue_destroy(queue);return 0;
}

int main(int argc,char**argv){try{return run(argc,argv);}catch(const std::exception&error){fprintf(stderr,"C++ failure: %s\n",error.what());return 1;}}
