set -e
source /tmp/blender-web-emsdk/emsdk_env.sh >/dev/null 2>&1
export BINARYEN_CORES=1
emcc -O2 -pthread -msimd128 -fwasm-exceptions -DHAVE_CONFIG_H -Ibuild/native/parity-probes/cpython/ffi/build -Ibuild/native/parity-probes/cpython/ffi/source/include -Ibuild/native/parity-probes/cpython/ffi/build/include -Ibuild/native/parity-probes/cpython/ffi/source/src -c build/native/parity-probes/ffi-events-exit/ffi.c -o build/native/parity-probes/ffi-events-exit/ffi.o
cp build/native/parity-probes/cpython/prefix/lib/libffi.a build/native/parity-probes/ffi-events-exit/libffi.a
emar r build/native/parity-probes/ffi-events-exit/libffi.a build/native/parity-probes/ffi-events-exit/ffi.o
em++ build/native/parity-probes/ffi-events-exit/check.cc build/native/parity-probes/ffi-events-exit/libffi.a -Ibuild/native/parity-probes/cpython/prefix/include -O2 -g1 -pthread -msimd128 -fwasm-exceptions -sALLOW_TABLE_GROWTH=1 -sPROXY_TO_PTHREAD=1 -sPTHREAD_POOL_SIZE=20 -sPTHREAD_POOL_SIZE_STRICT=0 -sEXIT_RUNTIME=1 -sALLOW_MEMORY_GROWTH=1 -sENVIRONMENT=node,worker '-sEXPORTED_FUNCTIONS=["_main","_malloc","_free"]' -Wl,--wrap=ffi_closure_alloc -Wl,--wrap=ffi_prep_closure_loc -Wl,--wrap=ffi_closure_free -Wl,--wrap=pthread_create -Wl,--wrap=emscripten_futex_wait -o build/native/parity-probes/ffi-events-exit/check.js
